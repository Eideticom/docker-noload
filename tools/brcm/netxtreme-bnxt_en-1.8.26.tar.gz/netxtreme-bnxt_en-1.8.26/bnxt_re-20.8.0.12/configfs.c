/*
 * Copyright (c) 2015-2017, Broadcom. All rights reserved.  The term
 * Broadcom refers to Broadcom Limited and/or its subsidiaries.
 *
 * This software is available to you under a choice of one of two
 * licenses.  You may choose to be licensed under the terms of the GNU
 * General Public License (GPL) Version 2, available from the file
 * COPYING in the main directory of this source tree, or the
 * BSD license below:
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *
 * Description: Enables configfs interface
 */

#include "configfs.h"

static struct bnxt_re_dev *__get_rdev_from_name(const char *name)
{
	struct bnxt_re_dev *rdev;
	u8 found = false;

	mutex_lock(&bnxt_re_dev_lock);
	list_for_each_entry(rdev, &bnxt_re_dev_list, list) {
		if (!strcmp(name, rdev->ibdev.name)) {
			found = true;
			break;
		}
	}
	mutex_unlock(&bnxt_re_dev_lock);

	return found ? rdev : ERR_PTR(-ENODEV);
}

static struct bnxt_re_cc_group * __get_cc_group(struct config_item *item)
{
	struct config_group *group = container_of(item, struct config_group,
						  cg_item);
	struct bnxt_re_cc_group *ccgrp =
			container_of(group, struct bnxt_re_cc_group, group);
        return ccgrp;
}

static ssize_t apply_show(struct config_item *item, char *buf)
{
	return 0;
}

static ssize_t apply_store(struct config_item *item, const char *buf,
			   size_t count)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;
	struct bnxt_re_dscp2pri d2p;
	unsigned int val;
	int rc = 0;

	if (!ccgrp)
		return -EINVAL;

	rdev = ccgrp->rdev;
	sscanf(buf, "%x\n", &val);
	if (val == BNXT_RE_MODIFY_CC) {
		/* For VLAN transmission disablement */
		if (rdev->cc_param.mask &
		    BNXT_QPLIB_CC_PARAM_MASK_VLAN_TX_DISABLE) {
			rdev->cc_param.mask &=
				~BNXT_QPLIB_CC_PARAM_MASK_VLAN_TX_DISABLE;
			rc = bnxt_re_vlan_tx_disable(rdev);
			if (rc)
				dev_err(rdev_to_dev(rdev),
					"Failed to disable VLAN tx\n");
		}
		rc = bnxt_qplib_modify_cc(&rdev->qplib_res,
					  &rdev->cc_param);
		if (rc)
			dev_err(rdev_to_dev(rdev),
				"Failed to apply cc settings\n");
		mutex_lock(&rdev->cc_lock);
		d2p.dscp = rdev->cc_param.tos_dscp;
		d2p.pri = rdev->dscp_prio;
		mutex_unlock(&rdev->cc_lock);
		d2p.mask = 0x3F;
		rc = bnxt_re_set_hwrm_dscp2pri(rdev, &d2p, 1);
		if (rc)
			dev_err(rdev_to_dev(rdev),
				"Failed to updated dscp\n");
	}

	return rc ? -EINVAL : strnlen(buf, count);
}
CONFIGFS_ATTR(, apply);

static ssize_t alt_tos_dscp_show(struct config_item *item, char *buf)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;

	if (!ccgrp)
		return -EINVAL;

	rdev = ccgrp->rdev;
	return sprintf(buf,"%#x\n", rdev->cc_param.alt_tos_dscp);
}

static ssize_t alt_tos_dscp_store(struct config_item *item, const char *buf,
				   size_t count)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;
	unsigned int val;

	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;
	sscanf(buf, "%x\n", &val);
	rdev->cc_param.alt_tos_dscp = val & 0xFF;
	rdev->cc_param.mask |= CMDQ_MODIFY_ROCE_CC_MODIFY_MASK_ALT_TOS_DSCP;

	return strnlen(buf, count);
}

CONFIGFS_ATTR(, alt_tos_dscp);

static ssize_t alt_vlan_pcp_show(struct config_item *item, char *buf)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;

	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;

	return sprintf(buf,"%#x\n", rdev->cc_param.alt_vlan_pcp);
}

static ssize_t alt_vlan_pcp_store(struct config_item *item, const char *buf,
				  size_t count)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;
	unsigned int val;

	if (!ccgrp)
		return -EINVAL;

	rdev = ccgrp->rdev;
	sscanf(buf, "%x\n", &val);
	rdev->cc_param.alt_vlan_pcp = val & 0xFF;
	rdev->cc_param.mask |= CMDQ_MODIFY_ROCE_CC_MODIFY_MASK_ALT_VLAN_PCP;

	return strnlen(buf, count);
}
CONFIGFS_ATTR(, alt_vlan_pcp);

static ssize_t cc_mode_show(struct config_item *item, char *buf)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;

	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;

	return sprintf(buf,"%#x\n", rdev->cc_param.cc_mode);
}

static ssize_t cc_mode_store(struct config_item *item, const char *buf,
			     size_t count)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;
	unsigned int val;

	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;

	sscanf(buf, "%x\n", &val);
	rdev->cc_param.cc_mode = val & 0xFF;
	rdev->cc_param.mask |= CMDQ_MODIFY_ROCE_CC_MODIFY_MASK_CC_MODE;

	return strnlen(buf, count);
}
CONFIGFS_ATTR(, cc_mode);

static ssize_t enable_show(struct config_item *item, char *buf)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;

	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;

	return sprintf(buf,"%#x\n", rdev->cc_param.enable);
}

static ssize_t enable_store(struct config_item *item, const char *buf,
			    size_t count)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;
	unsigned int val;

	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;

	sscanf(buf, "%x\n", &val);
	rdev->cc_param.enable = val & 0xFF;
	rdev->cc_param.mask |= CMDQ_MODIFY_ROCE_CC_MODIFY_MASK_ENABLE_CC;

	return strnlen(buf, count);
}
CONFIGFS_ATTR(, enable);

static ssize_t g_show(struct config_item *item, char *buf)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;
	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;

	return sprintf(buf,"%#x\n", rdev->cc_param.g);
}

static ssize_t g_store(struct config_item *item, const char *buf,
		       size_t count)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;
	unsigned int val;

	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;

	sscanf(buf, "%x\n", &val);
	rdev->cc_param.g = val & 0xFF;
	rdev->cc_param.mask |= CMDQ_MODIFY_ROCE_CC_MODIFY_MASK_G;

	return strnlen(buf, count);
}
CONFIGFS_ATTR(, g);

static ssize_t init_cr_show(struct config_item *item, char *buf)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;

	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;

	return sprintf(buf,"%#x\n", rdev->cc_param.init_cr);
}

static ssize_t init_cr_store(struct config_item *item, const char *buf,
			     size_t count)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;
	unsigned int val;

	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;

	sscanf(buf, "%x\n", &val);
	rdev->cc_param.init_cr = val & 0xFFFF;
	rdev->cc_param.mask |= CMDQ_MODIFY_ROCE_CC_MODIFY_MASK_INIT_CR;

	return strnlen(buf, count);
}
CONFIGFS_ATTR(, init_cr);

static ssize_t inact_cp_show(struct config_item *item, char *buf)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;
	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;

	return sprintf(buf,"%#x\n", rdev->cc_param.inact_cp);
}

static ssize_t inact_cp_store(struct config_item *item, const char *buf,
			      size_t count)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;
	unsigned int val;

	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;

	sscanf(buf, "%x\n", &val);
	rdev->cc_param.inact_cp = val & 0xFFFF;
	rdev->cc_param.mask |= CMDQ_MODIFY_ROCE_CC_MODIFY_MASK_INACT_CP;

	return strnlen(buf, count);
}
CONFIGFS_ATTR(, inact_cp);

static ssize_t init_tr_show(struct config_item *item, char *buf)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;

	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;

	return sprintf(buf,"%#x\n", rdev->cc_param.init_tr);
}

static ssize_t init_tr_store(struct config_item *item, const char *buf,
			     size_t count)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;
	unsigned int val;

	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;

	sscanf(buf, "%x\n", &val);
	rdev->cc_param.init_tr = val & 0xFFFF;
	rdev->cc_param.mask |= CMDQ_MODIFY_ROCE_CC_MODIFY_MASK_INIT_TR;

	return strnlen(buf, count);
}
CONFIGFS_ATTR(, init_tr);

static ssize_t nph_per_state_show(struct config_item *item, char *buf)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;

	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;

	return sprintf(buf,"%#x\n", rdev->cc_param.nph_per_state);
}

static ssize_t nph_per_state_store(struct config_item *item, const char *buf,
			   size_t count)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;
	unsigned int val;

	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;

	sscanf(buf, "%x\n", &val);
	rdev->cc_param.nph_per_state = val & 0xFF;
	rdev->cc_param.mask |=
		CMDQ_MODIFY_ROCE_CC_MODIFY_MASK_NUMPHASEPERSTATE;

	return strnlen(buf, count);
}
CONFIGFS_ATTR(, nph_per_state);

static ssize_t rtt_show(struct config_item *item, char *buf)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;

	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;

	return sprintf(buf,"%#x\n", rdev->cc_param.rtt);
}

static ssize_t rtt_store(struct config_item *item, const char *buf,
			 size_t count)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;
	unsigned int val;

	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;

	sscanf(buf, "%x\n", &val);
	rdev->cc_param.rtt = val & 0xFFFF;
	rdev->cc_param.mask |= CMDQ_MODIFY_ROCE_CC_MODIFY_MASK_RTT;

	return strnlen(buf, count);
}
CONFIGFS_ATTR(, rtt);

static ssize_t tcp_cp_show(struct config_item *item, char *buf)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;

	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;

	return sprintf(buf,"%#x\n", rdev->cc_param.tcp_cp);
}

static ssize_t tcp_cp_store(struct config_item *item, const char *buf,
			    size_t count)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;
	unsigned int val;

	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;

	sscanf(buf, "%x\n", &val);
	rdev->cc_param.tcp_cp = val & 0xFFFF;
	rdev->cc_param.mask |= CMDQ_MODIFY_ROCE_CC_MODIFY_MASK_TCP_CP;

	return strnlen(buf, count);
}
CONFIGFS_ATTR(, tcp_cp);

static ssize_t tos_dscp_show(struct config_item *item, char *buf)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;

	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;

	return sprintf(buf,"%#x\n", rdev->cc_param.tos_dscp);
}

static ssize_t tos_dscp_store(struct config_item *item, const char *buf,
			      size_t count)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;
	unsigned int val;

	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;

	sscanf(buf, "%x\n", &val);
	mutex_lock(&rdev->cc_lock);
	rdev->cc_param.tos_dscp = val & 0xFF;
	mutex_unlock(&rdev->cc_lock);
	rdev->cc_param.mask |= CMDQ_MODIFY_ROCE_CC_MODIFY_MASK_TOS_DSCP;

	return strnlen(buf, count);
}
CONFIGFS_ATTR(, tos_dscp);

static ssize_t tos_ecn_show(struct config_item *item, char *buf)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;

	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;

	return sprintf(buf,"%#x\n", rdev->cc_param.tos_ecn);
}

static ssize_t tos_ecn_store(struct config_item *item, const char *buf,
			     size_t count)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;
	unsigned int val;

	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;

	sscanf(buf, "%x\n", &val);
	rdev->cc_param.tos_ecn = val & 0xFF;
	rdev->cc_param.mask |= CMDQ_MODIFY_ROCE_CC_MODIFY_MASK_TOS_ECN;

	return strnlen(buf, count);
}
CONFIGFS_ATTR(, tos_ecn);

static ssize_t vlan_tx_disable_show(struct config_item *item, char *buf)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;

	if (!ccgrp)
		return -EINVAL;

	rdev = ccgrp->rdev;
	return sprintf(buf,"%#x\n", rdev->cc_param.vlan_tx_disable);
}

static ssize_t vlan_tx_disable_store(struct config_item *item, const char *buf,
				     size_t count)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;
	unsigned int val;

	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;
	sscanf(buf, "%x\n", &val);
	rdev->cc_param.vlan_tx_disable = val & 0x1;
	rdev->cc_param.mask |= BNXT_QPLIB_CC_PARAM_MASK_VLAN_TX_DISABLE;

	return strnlen(buf, count);
}

CONFIGFS_ATTR(, vlan_tx_disable);

static struct configfs_attribute *bnxt_re_cc_attrs[] = {
	CONFIGFS_ATTR_ADD(attr_apply),
	CONFIGFS_ATTR_ADD(attr_alt_tos_dscp),
	CONFIGFS_ATTR_ADD(attr_alt_vlan_pcp),
	CONFIGFS_ATTR_ADD(attr_cc_mode),
	CONFIGFS_ATTR_ADD(attr_enable),
	CONFIGFS_ATTR_ADD(attr_g),
	CONFIGFS_ATTR_ADD(attr_init_cr),
	CONFIGFS_ATTR_ADD(attr_inact_cp),
	CONFIGFS_ATTR_ADD(attr_init_tr),
	CONFIGFS_ATTR_ADD(attr_nph_per_state),
	CONFIGFS_ATTR_ADD(attr_rtt),
	CONFIGFS_ATTR_ADD(attr_tcp_cp),
	CONFIGFS_ATTR_ADD(attr_tos_dscp),
	CONFIGFS_ATTR_ADD(attr_tos_ecn),
	CONFIGFS_ATTR_ADD(attr_vlan_tx_disable),
	NULL,
};

#ifdef HAVE_OLD_CONFIGFS_API
static ssize_t bnxt_re_ccgrp_attr_show(struct config_item *item,
				       struct configfs_attribute *attr,
				       char *page)
{
	struct configfs_attr *ccgrp_attr =
			container_of(attr, struct configfs_attr, attr);
	ssize_t rc = -EINVAL;

	if (!ccgrp_attr)
		goto out;

	if (ccgrp_attr->show)
		rc = ccgrp_attr->show(item, page);
out:
	return rc;
}

static ssize_t bnxt_re_ccgrp_attr_store(struct config_item *item,
					struct configfs_attribute *attr,
					const char *page, size_t count)
{
	struct configfs_attr *ccgrp_attr =
			container_of(attr, struct configfs_attr, attr);
	ssize_t rc = -EINVAL;

	if (!ccgrp_attr)
		goto out;
	if (ccgrp_attr->store)
		rc = ccgrp_attr->store(item, page, count);
out:
	return rc;
}

static struct configfs_item_operations bnxt_re_ccgrp_ops = {
	.show_attribute         = bnxt_re_ccgrp_attr_show,
	.store_attribute	= bnxt_re_ccgrp_attr_store,
};

#else
static struct configfs_item_operations bnxt_re_ccgrp_ops = {
};
#endif

static struct config_item_type bnxt_re_ccgrp_type = {
	.ct_attrs = bnxt_re_cc_attrs,
	.ct_item_ops = &bnxt_re_ccgrp_ops,
	.ct_owner = THIS_MODULE,
};

static int make_bnxt_re_cc(struct bnxt_re_port_group *portgrp,
			   struct bnxt_re_dev *rdev, u32 gidx)
{
	struct bnxt_re_cc_group *ccgrp;
	int rc;

	ccgrp = kzalloc(sizeof(*ccgrp), GFP_KERNEL);
	if (!ccgrp) {
		rc = -ENOMEM;
		goto out;
	}

	ccgrp->rdev = rdev;
	config_group_init_type_name(&ccgrp->group, "cc", &bnxt_re_ccgrp_type);
#ifndef HAVE_CFGFS_ADD_DEF_GRP
	portgrp->nportgrp.default_groups = portgrp->default_grp;
	portgrp->default_grp[gidx] = &ccgrp->group;
	portgrp->default_grp[gidx + 1] = NULL;
#else
	configfs_add_default_group(&ccgrp->group, &portgrp->nportgrp);
#endif
	portgrp->ccgrp = ccgrp;

	return 0;
out:
	kfree(ccgrp);
	return rc;
}

static ssize_t min_tx_depth_show(struct config_item *item, char *buf)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;

	if (!ccgrp)
		return -EINVAL;

	rdev = ccgrp->rdev;
	return sprintf(buf, "%#x\n", rdev->min_tx_depth);
}

static ssize_t min_tx_depth_store(struct config_item *item, const char *buf,
				  size_t count)
{
	struct bnxt_re_cc_group *ccgrp = __get_cc_group(item);
	struct bnxt_re_dev *rdev;
	unsigned int val;

	if (!ccgrp)
		return -EINVAL;
	rdev = ccgrp->rdev;
	sscanf(buf, "%x\n", &val);
	if (val > rdev->dev_attr.max_qp_wqes)
		return -EINVAL;

	rdev->min_tx_depth = val;

	return strnlen(buf, count);
}

CONFIGFS_ATTR(, min_tx_depth);

static struct configfs_attribute *bnxt_re_tun_attrs[] = {
	CONFIGFS_ATTR_ADD(attr_min_tx_depth),
	NULL,
};

#ifdef HAVE_OLD_CONFIGFS_API
static ssize_t bnxt_re_tungrp_attr_show(struct config_item *item,
					struct configfs_attribute *attr,
					char *page)
{
	struct configfs_attr *tungrp_attr =
			container_of(attr, struct configfs_attr, attr);
	ssize_t rc = -EINVAL;

	if (!tungrp_attr)
		goto out;

	if (tungrp_attr->show)
		rc = tungrp_attr->show(item, page);
out:
	return rc;
}

static ssize_t bnxt_re_tungrp_attr_store(struct config_item *item,
					 struct configfs_attribute *attr,
					 const char *page, size_t count)
{
	struct configfs_attr *tungrp_attr =
			container_of(attr, struct configfs_attr, attr);
	ssize_t rc = -EINVAL;

	if (!tungrp_attr)
		goto out;
	if (tungrp_attr->store)
		rc = tungrp_attr->store(item, page, count);
out:
	return rc;
}

static struct configfs_item_operations bnxt_re_tungrp_ops = {
	.show_attribute         = bnxt_re_tungrp_attr_show,
	.store_attribute	= bnxt_re_tungrp_attr_store,
};

#else
static struct configfs_item_operations bnxt_re_tungrp_ops = {
};
#endif

static struct config_item_type bnxt_re_tungrp_type = {
	.ct_attrs = bnxt_re_tun_attrs,
	.ct_item_ops = &bnxt_re_tungrp_ops,
	.ct_owner = THIS_MODULE,
};

static int make_bnxt_re_tunables(struct bnxt_re_port_group *portgrp,
				 struct bnxt_re_dev *rdev, u32 gidx)
{
	struct bnxt_re_tunable_group *tungrp;
	int rc;

	tungrp = kzalloc(sizeof(*tungrp), GFP_KERNEL);
	if (!tungrp) {
		rc = -ENOMEM;
		goto out;
	}

	tungrp->rdev = rdev;
	config_group_init_type_name(&tungrp->group, "tunables",
				    &bnxt_re_tungrp_type);
#ifndef HAVE_CFGFS_ADD_DEF_GRP
	portgrp->nportgrp.default_groups = portgrp->default_grp;
	portgrp->default_grp[gidx] = &tungrp->group;
	portgrp->default_grp[gidx + 1] = NULL;
#else
	configfs_add_default_group(&tungrp->group, &portgrp->nportgrp);
#endif
	portgrp->tungrp = tungrp;

	return 0;
out:
	kfree(tungrp);
	return rc;
}


static void bnxt_re_release_nport_group(struct config_item *item)
{
	struct config_group *group = container_of(item, struct config_group,
						  cg_item);
	struct bnxt_re_port_group *portgrp =
				container_of(group, struct bnxt_re_port_group,
					     nportgrp);
	kfree(portgrp->ccgrp);
}

static struct configfs_item_operations bnxt_re_nport_item_ops = {
        .release = bnxt_re_release_nport_group
};

static struct config_item_type bnxt_re_nportgrp_type = {
        .ct_item_ops = &bnxt_re_nport_item_ops,
        .ct_owner = THIS_MODULE,
};

static int make_bnxt_re_ports(struct bnxt_re_dev_group *devgrp,
			      struct bnxt_re_dev *rdev)
{
#ifndef HAVE_CFGFS_ADD_DEF_GRP
	struct config_group **portsgrp = NULL;
#endif
	struct bnxt_re_port_group *ports;
	struct ib_device *ibdev;
	int nports, rc, indx;

	if (!rdev)
		return -ENODEV;
	ibdev = &rdev->ibdev;
	nports = ibdev->phys_port_cnt;
	ports = kcalloc(nports, sizeof(*ports), GFP_KERNEL);
	if (!ports) {
		rc = -ENOMEM;
		goto out;
	}

#ifndef HAVE_CFGFS_ADD_DEF_GRP
	portsgrp = kcalloc(nports + 1, sizeof(*portsgrp), GFP_KERNEL);
	if (!portsgrp) {
		rc = -ENOMEM;
		goto out;
	}
#endif
	for (indx = 0; indx < nports; indx++) {
		char port_name[10];
		ports[indx].port_num = indx + 1;
		snprintf(port_name, sizeof(port_name), "%u", indx + 1);
		ports[indx].devgrp = devgrp;
		config_group_init_type_name(&ports[indx].nportgrp,
					    port_name, &bnxt_re_nportgrp_type);
		rc = make_bnxt_re_cc(&ports[indx], rdev, 0);
		if (rc)
			goto out;
		rc = make_bnxt_re_tunables(&ports[indx], rdev, 1);
		if (rc)
			goto out;
#ifndef HAVE_CFGFS_ADD_DEF_GRP
		portsgrp[indx] = &ports[indx].nportgrp;
#else
		configfs_add_default_group(&ports[indx].nportgrp,
					   &devgrp->port_group);
#endif
	}

#ifndef HAVE_CFGFS_ADD_DEF_GRP
	portsgrp[indx] = NULL;
	devgrp->default_portsgrp = portsgrp;
#endif
	devgrp->ports = ports;

	return 0;
out:
#ifndef HAVE_CFGFS_ADD_DEF_GRP
	kfree(portsgrp);
#endif
	kfree(ports);
	return rc;
}

static void bnxt_re_release_device_group(struct config_item *item)
{
	struct config_group *group = container_of(item, struct config_group,
						  cg_item);
	struct bnxt_re_dev_group *devgrp =
				container_of(group, struct bnxt_re_dev_group,
					     dev_group);
	kfree(devgrp);
}

static void bnxt_re_release_ports_group(struct config_item *item)
{
	struct config_group *group = container_of(item, struct config_group,
						  cg_item);
	struct bnxt_re_dev_group *devgrp =
				 container_of(group, struct bnxt_re_dev_group,
					      port_group);
#ifndef HAVE_CFGFS_ADD_DEF_GRP
	kfree(devgrp->default_portsgrp);
	devgrp->default_portsgrp = NULL;
#endif
	kfree(devgrp->ports);
	devgrp->ports = NULL;
}

static struct configfs_item_operations bnxt_re_ports_item_ops = {
	.release = bnxt_re_release_ports_group
};

static struct config_item_type bnxt_re_ports_group_type = {
	.ct_item_ops = &bnxt_re_ports_item_ops,
	.ct_owner = THIS_MODULE,
};

static struct configfs_item_operations bnxt_re_dev_item_ops = {
	.release = bnxt_re_release_device_group
};

static struct config_item_type bnxt_re_dev_group_type = {
	.ct_item_ops = &bnxt_re_dev_item_ops,
	.ct_owner = THIS_MODULE,
};

static struct config_group *make_bnxt_re_dev(struct config_group *group,
					     const char *name)
{
	struct bnxt_re_dev *rdev;
	struct bnxt_re_dev_group *devgrp = NULL;
	int rc = -ENODEV;

	rdev = __get_rdev_from_name(name);
	if (PTR_ERR(rdev) == -ENODEV)
		goto out;

	devgrp = kzalloc(sizeof(*devgrp), GFP_KERNEL);
	if (!devgrp) {
		rc = -ENOMEM;
		goto out;
	}

	strncpy(devgrp->name, name, sizeof(devgrp->name));
	config_group_init_type_name(&devgrp->port_group, "ports",
                                    &bnxt_re_ports_group_type);
	rc = make_bnxt_re_ports(devgrp, rdev);
	if (rc)
		goto out;
	config_group_init_type_name(&devgrp->dev_group, name,
                                    &bnxt_re_dev_group_type);
#ifndef HAVE_CFGFS_ADD_DEF_GRP
	devgrp->port_group.default_groups = devgrp->default_portsgrp;
	devgrp->dev_group.default_groups = devgrp->default_devgrp;
	devgrp->default_devgrp[0] = &devgrp->port_group;
	devgrp->default_devgrp[1] = NULL;
#else
	configfs_add_default_group(&devgrp->port_group,
				   &devgrp->dev_group);
#endif

	return &devgrp->dev_group;
out:
	kfree(devgrp);
	return ERR_PTR(rc);
}

static struct configfs_group_operations bnxt_re_group_ops = {
	.make_group = &make_bnxt_re_dev
};

static struct config_item_type bnxt_re_subsys_type = {
	.ct_group_ops	= &bnxt_re_group_ops,
	.ct_owner	= THIS_MODULE,
};

static struct configfs_subsystem bnxt_re_subsys = {
	.su_group	= {
		.cg_item	= {
			.ci_namebuf	= "bnxt_re",
			.ci_type	= &bnxt_re_subsys_type,
		},
	},
};

int bnxt_re_configfs_init(void)
{
	config_group_init(&bnxt_re_subsys.su_group);
	mutex_init(&bnxt_re_subsys.su_mutex);
	return configfs_register_subsystem(&bnxt_re_subsys);
}

void bnxt_re_configfs_exit(void)
{
	configfs_unregister_subsystem(&bnxt_re_subsys);
}
